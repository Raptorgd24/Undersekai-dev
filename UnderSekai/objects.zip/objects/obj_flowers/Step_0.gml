
event_inherited();
