// === MOVIMIENTO DEL MENÚ ===
var moved = false;

if (keyboard_check_pressed(vk_up) || keyboard_check_pressed(ord("W"))) {
    menu_index -= 1;
    moved = true;
}
if (keyboard_check_pressed(vk_down) || keyboard_check_pressed(ord("S"))) {
    menu_index += 1;
    moved = true;
}
// Toggle pantalla completa con F4
if (keyboard_check_pressed(vk_f4)) {
    if (!window_get_fullscreen()) {
        window_set_fullscreen(true);
    } else {
        window_set_fullscreen(false);
    }
}
// Capping (no circular)
if (menu_index < 0) menu_index = 0;
if (menu_index > array_length(menu_options) - 1) menu_index = array_length(menu_options) - 1;

// Si se movió, reproducir sonido y mostrar debug
if (moved) {
    audio_play_sound(snd_menumove, 1, false);
    show_debug_message("Selección actual: " + string(menu_options[menu_index]) + " (índice " + string(menu_index) + ")");
}

// === CONFIRMACIÓN DE SELECCIÓN ===
if (keyboard_check_pressed(vk_enter) || keyboard_check_pressed(ord("Z"))) {
    var option = menu_options[menu_index];
    show_debug_message("Opción seleccionada: " + option);
    audio_play_sound(snd_select, 1, false);
    
switch (option) {
    case "START":
        show_debug_message("Creando nuevo save.dat...");
        
        // Valores iniciales
        global.room_name = "rm_Room1";
        global.name = "Frisk";
        global.lv = 1;
        global.health = 20;
        global.gold = 0;
        global.objects = "[]";
        global.weapon = "Stick";
        global.armor = "Bandage";
        
        scr_save_game(); // guarda los valores iniciales
        room_goto(rm_Room1);
    break;
    
    case "CONTINUE":
        show_debug_message("Cargando save.dat...");
        scr_load_game(); // carga valores guardados
        room_goto(asset_get_index(global.room_name)); // carga la room que estaba guardada
    break;
    
    case "RESET":
        show_debug_message("Reseteando save.dat...");
        if (file_exists("save.dat")) file_delete("save.dat");
        
        // Restablecer a valores iniciales
        global.room_name = "rm_Room1";
        global.name = "Frisk";
        global.lv = 1;
        global.health = 20;
        global.gold = 0;
        global.objects = "[]";
        global.weapon = "Stick";
        global.armor = "Bandage";
        
        scr_save_game();
        room_goto(rm_Room1);
    break;
    
    case "OPTIONS":
        show_debug_message("Abriendo menú de opciones...");
        room_goto(rm_options);
    break;
}

}
