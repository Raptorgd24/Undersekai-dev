function scr_events(_event){
	if (_event == 1){
		
		scr_dialogue("noone", 8, "The flowers aren't blooming lmao", false);
		
	}

}