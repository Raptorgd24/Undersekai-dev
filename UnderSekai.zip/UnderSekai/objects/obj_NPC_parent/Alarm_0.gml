//alarma 0
// Crear explosión en la posición del NPC -20,-20
var boom = instance_create_layer(x - 20, y - 20, "Instances_1", obj_boom_temp);

// Guardar referencia de este NPC en el boom
boom.parent_npc = id;
