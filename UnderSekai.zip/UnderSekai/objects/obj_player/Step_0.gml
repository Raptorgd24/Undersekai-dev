// Velocidad base
var base_vel = 1;
var velocidad_actual = base_vel;

// Si se mantiene presionada la tecla X, reducir velocidad a 1.25
if (keyboard_check(ord("X"))) {
    velocidad_actual = 1.25;
}

// Detectar movimiento en X y Y (teclas flechas y WASD)
var mx = keyboard_check(vk_right) || keyboard_check(ord("D")) - (keyboard_check(vk_left) || keyboard_check(ord("A")));
var my = keyboard_check(vk_down)  || keyboard_check(ord("S")) - (keyboard_check(vk_up)   || keyboard_check(ord("W")));

// Si se presiona alguna dirección, mover al jugador
if (mx != 0 || my != 0) {
    var dir = point_direction(0, 0, mx, my);
    x += lengthdir_x(velocidad_actual, dir);
    y += lengthdir_y(velocidad_actual, dir);
}
