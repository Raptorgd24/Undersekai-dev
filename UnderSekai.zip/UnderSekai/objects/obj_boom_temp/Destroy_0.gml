
// Si existe la referencia a un NPC, destruirlo también
if (variable_instance_exists(self, "obj_NPC_parent")) {
    if (instance_exists(obj_NPC_parent)) {
        with (obj_NPC_parent) {
            instance_destroy();
        }
    }
}
