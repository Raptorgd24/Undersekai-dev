

if (randomassbool = true)
	{
		if (place_meeting(x, y, obj_player)){
	scr_events(1);
		}
	}